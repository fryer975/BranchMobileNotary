import './editor.scss';

export default function FlexControl( { children } ) {
	return <div className="gblocks-flex-control">{ children }</div>;
}
