export default function getBorderAttributes() {
	return {
		borders: {
			type: 'object',
			default: {},
		},
	};
}
